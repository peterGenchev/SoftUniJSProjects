import { get } from './api.js'
import { del } from './api.js'
import { post } from './api.js'
import { put } from './api.js'

export async function getAll() {

    return get('/data/albums?sortBy=_createdOn%20desc')
}

export async function getById(id) {

    return get('/data/albums/' + id);
}

export async function deleteById(id) {
    return del('/data/albums/' + id)
}

export async function createItem(itemData) {
    return post('/data/albums', itemData)
}

export async function editItem(id, itemData) {
    return put('/data/albums/' + id, itemData)
}







