exports.SECRET = '5e7a33b6-e13c-4381-8920-adbc525a1be6';
exports.TOKEN_KEY = 'token';
